num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())

products = num1 * num2 * num3 * num4

averages = (num1 + num2 + num3 + num4) / 4


print (f'{products:.0f}', end= ' ')
print(f'{averages:.0f}')
print (f'{products:.3f}', end= ' ')
print(f'{averages:.3f}')





